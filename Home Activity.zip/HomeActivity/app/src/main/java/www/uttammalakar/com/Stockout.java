package www.uttammalakar.com;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Stockout extends AppCompatActivity implements View.OnClickListener {
    private EditText productName,priceEdittext,quantityEdittext;

    MydatabaseHelper mydatabaseHelper;

    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock_in);

        mydatabaseHelper=new MydatabaseHelper(this);

        sqLiteDatabase=mydatabaseHelper.getWritableDatabase();

        productName=(EditText) findViewById(R.id.nameeditstockin);
        priceEdittext= (EditText) findViewById(R.id.priceeditstockin);
        quantityEdittext=(EditText)findViewById(R.id.producteditstockin);
        Button savebutton = (Button) findViewById(R.id.buttonstockin);
        savebutton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (productName.length() == 0) {
            productName.setError("Enter name");
        } else if (priceEdittext.length() == 0) {
            priceEdittext.setError("Enter price");
        } else if (quantityEdittext.length() == 0) {
            quantityEdittext.setError("Enter quantity");
        } else {
            String name = productName.getText().toString();
            String price = priceEdittext.getText().toString();
            String quantity = quantityEdittext.getText().toString();
            if (v.getId() == R.id.buttonstockin) {

                long rowId = mydatabaseHelper.insertData("stockout", name, price, quantity);

                if (rowId == -1) {

                    Toast.makeText(getApplicationContext(), "NOT SAVE ", Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(getApplicationContext(), "SAVE", Toast.LENGTH_SHORT).show();

                }

            }

        }
    }

}